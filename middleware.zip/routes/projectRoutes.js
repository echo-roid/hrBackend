// const express = require('express');
// const router = express.Router();
// const projectController = require('../controllers/projectController');
// const upload = require('../middleware/upload');

// // Existing routes
// router.post('/', upload.single('photo'), projectController.createProject);
// router.get('/', projectController.getProjects);
// router.get('/:id', projectController.getProjectDetails);

// // New route for updating photo
// router.put('/:id/photo', upload.single('photo'), projectController.updateProjectPhoto);

// module.exports = router;